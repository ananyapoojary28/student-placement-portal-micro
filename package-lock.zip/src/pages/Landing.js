import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Landing.css';

const Landing = () => {
  const navigate = useNavigate();
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e) => {
      setMousePosition({
        x: (e.clientX / window.innerWidth - 0.5) * 20,
        y: (e.clientY / window.innerHeight - 0.5) * 20,
      });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const handleFeatureClick = (path) => {
    navigate('/login');
  };

  return (
    <div className="landing-container">
      {/* Animated Background */}
      <div className="bg-gradient"></div>
      <div className="bg-particles">
        {[...Array(50)].map((_, i) => (
          <div key={i} className="particle" style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 10}s`,
            animationDuration: `${10 + Math.random() * 20}s`,
          }}></div>
        ))}
      </div>
      <div className="bg-orb" style={{
        transform: `translate(${mousePosition.x}px, ${mousePosition.y}px)`
      }}></div>
      <div className="bg-orb-2" style={{
        transform: `translate(${-mousePosition.x}px, ${-mousePosition.y}px)`
      }}></div>

      {/* Navigation */}
      <nav className="landing-nav">
        <div className="logo">
          <span className="logo-icon">🎓</span>
          PlacementPortal
        </div>
        <div className="nav-buttons">
          <button onClick={() => navigate('/login')} className="nav-btn nav-login">Login</button>
          <button onClick={() => navigate('/register')} className="nav-btn nav-register">Get Started</button>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="hero-section">
        <div className="hero-content">
          <h1 className="hero-title">
            Student Skill Tracker
            <span className="hero-title-gradient">&</span>
            Placement Portal
          </h1>
          <p className="hero-subtitle">
            AI-Powered ATS System | Smart Resume Builder | Intelligent Job Matching
          </p>
          <div className="hero-buttons">
            <button onClick={() => navigate('/register')} className="hero-btn primary">
              Start Your Journey
              <span className="btn-arrow">→</span>
            </button>
            <button onClick={() => navigate('/login')} className="hero-btn secondary">
              Existing User? Login
            </button>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="features-section">
        <h2 className="section-title">Why Choose Us?</h2>
        <div className="features-grid">
          <div className="feature-card" onClick={() => handleFeatureClick('skills')}>
            <div className="feature-icon">🎯</div>
            <h3>Skill Tracker</h3>
            <p>Track your skills with AI-powered recommendations and progress analytics</p>
            <div className="feature-hover-effect"></div>
          </div>
          <div className="feature-card" onClick={() => handleFeatureClick('resume')}>
            <div className="feature-icon">📄</div>
            <h3>Resume Builder</h3>
            <p>Create professional resumes with multiple templates and one-click PDF export</p>
            <div className="feature-hover-effect"></div>
          </div>
          <div className="feature-card" onClick={() => handleFeatureClick('ats')}>
            <div className="feature-icon">🤖</div>
            <h3>ATS System</h3>
            <p>AI-powered skill matching algorithm ranks candidates based on job requirements</p>
            <div className="feature-hover-effect"></div>
          </div>
          <div className="feature-card" onClick={() => handleFeatureClick('jobs')}>
            <div className="feature-icon">💼</div>
            <h3>Job Portal</h3>
            <p>Browse and apply to jobs from top companies with one click</p>
            <div className="feature-hover-effect"></div>
          </div>
          <div className="feature-card" onClick={() => handleFeatureClick('tracking')}>
            <div className="feature-icon">📊</div>
            <h3>Application Tracking</h3>
            <p>Track your applications from Applied to Selected with real-time status</p>
            <div className="feature-hover-effect"></div>
          </div>
          <div className="feature-card" onClick={() => handleFeatureClick('analytics')}>
            <div className="feature-icon">📈</div>
            <h3>Placement Analytics</h3>
            <p>Get insights on placement trends and your readiness score</p>
            <div className="feature-hover-effect"></div>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="stats-section">
        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-number" data-count="500">500+</div>
            <div className="stat-label">Students Placed</div>
          </div>
          <div className="stat-card">
            <div className="stat-number" data-count="50">50+</div>
            <div className="stat-label">Partner Companies</div>
          </div>
          <div className="stat-card">
            <div className="stat-number" data-count="95">95%</div>
            <div className="stat-label">Success Rate</div>
          </div>
          <div className="stat-card">
            <div className="stat-number" data-count="1000">1000+</div>
            <div className="stat-label">Job Applications</div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="cta-section">
        <h2>Ready to Start Your Career Journey?</h2>
        <p>Join thousands of students who found their dream jobs through PlacementPortal</p>
        <button onClick={() => navigate('/register')} className="cta-btn">
          Get Started Free
          <span className="btn-glow"></span>
        </button>
      </div>

      {/* Footer */}
      <footer className="footer">
        <p>© 2024 PlacementPortal. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default Landing;