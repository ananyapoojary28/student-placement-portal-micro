import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getJobs, createJob, getApplicationsByJob, updateApplicationStatus, analyzeApplication } from '../services/api';
import './RecruiterDashboard.css';

const RecruiterDashboard = () => {
  const [jobs, setJobs] = useState([]);
  const [applications, setApplications] = useState({});
  const [selectedJob, setSelectedJob] = useState(null);
  const [showJobForm, setShowJobForm] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [formData, setFormData] = useState({
    companyName: '',
    jobTitle: '',
    location: '',
    salary: '',
    requiredSkills: '',
    description: '',
    deadline: ''
  });
  const navigate = useNavigate();

  useEffect(() => {
    fetchJobs();
  }, []);

  const fetchJobs = async () => {
    try {
      const res = await getJobs();
      setJobs(res.data);
    } catch (error) {
      console.error('Error fetching jobs:', error);
    }
  };

  const fetchApplications = async (jobId) => {
    try {
      const res = await getApplicationsByJob(jobId);
      setApplications({ ...applications, [jobId]: res.data });
    } catch (error) {
      console.error('Error fetching applications:', error);
    }
  };

  const handleViewApplicants = async (jobId) => {
    if (applications[jobId]) {
      setSelectedJob(selectedJob === jobId ? null : jobId);
    } else {
      await fetchApplications(jobId);
      setSelectedJob(jobId);
    }
  };

  const handleCreateJob = async (e) => {
    e.preventDefault();
    try {
      const skillsArray = formData.requiredSkills.split(',').map(s => s.trim());
      await createJob({ ...formData, requiredSkills: skillsArray });
      setShowJobForm(false);
      setFormData({
        companyName: '', jobTitle: '', location: '', salary: '',
        requiredSkills: '', description: '', deadline: ''
      });
      fetchJobs();
    } catch (error) {
      console.error('Error creating job:', error);
    }
  };

  const updateStatus = async (applicationId, newStatus) => {
    try {
      await updateApplicationStatus(applicationId, { status: newStatus });
      await fetchApplications(selectedJob);
      alert(`Application ${newStatus} successfully!`);
    } catch (error) {
      console.error('Error updating status:', error);
      alert('Failed to update status');
    }
  };

  const handleAnalyzeResume = async (applicationId) => {
    setAnalyzing(true);
    try {
      const response = await analyzeApplication(applicationId);
      alert(`✅ Resume Analyzed!\n\nATS Score: ${response.data.atsScore}%\n\n📊 Breakdown:\n• Skills: ${response.data.breakdown.skills}%\n• Experience: ${response.data.breakdown.experience}%\n• Education: ${response.data.breakdown.education}%\n• Projects: ${response.data.breakdown.projects}%`);
      // Refresh applications to show updated score
      await fetchApplications(selectedJob);
    } catch (error) {
      console.error('Error analyzing resume:', error);
      alert(error.response?.data?.message || 'Failed to analyze resume');
    } finally {
      setAnalyzing(false);
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login');
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'Selected': return '#28a745';
      case 'Shortlisted': return '#17a2b8';
      case 'Rejected': return '#dc3545';
      case 'Applied': return '#ffc107';
      default: return '#6c757d';
    }
  };

  return (
    <div className="recruiter-container">
      <nav className="recruiter-nav">
        <h1>📋 Recruiter Dashboard</h1>
        <button onClick={logout} className="logout-btn">Logout</button>
      </nav>

      <div className="recruiter-content">
        {/* Post Job Button */}
        <button className="post-job-btn" onClick={() => setShowJobForm(!showJobForm)}>
          {showJobForm ? '✖ Cancel' : '+ Post New Job'}
        </button>

        {/* Job Form */}
        {showJobForm && (
          <form className="job-form" onSubmit={handleCreateJob}>
            <h3>Create New Job Opening</h3>
            <div className="form-row">
              <input type="text" placeholder="Company Name" value={formData.companyName}
                onChange={(e) => setFormData({...formData, companyName: e.target.value})} required />
              <input type="text" placeholder="Job Title" value={formData.jobTitle}
                onChange={(e) => setFormData({...formData, jobTitle: e.target.value})} required />
            </div>
            <div className="form-row">
              <input type="text" placeholder="Location" value={formData.location}
                onChange={(e) => setFormData({...formData, location: e.target.value})} required />
              <input type="text" placeholder="Salary" value={formData.salary}
                onChange={(e) => setFormData({...formData, salary: e.target.value})} />
            </div>
            <input type="text" placeholder="Required Skills (comma separated: React, Node.js, MongoDB)"
              value={formData.requiredSkills}
              onChange={(e) => setFormData({...formData, requiredSkills: e.target.value})} required />
            <textarea placeholder="Job Description" rows="3" value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})} required />
            <input type="date" placeholder="Deadline" value={formData.deadline}
              onChange={(e) => setFormData({...formData, deadline: e.target.value})} required />
            <button type="submit" className="submit-job-btn">Post Job</button>
          </form>
        )}

        {/* Jobs List */}
        <div className="jobs-list-recruiter">
          <h2>Your Job Postings</h2>
          {jobs.length === 0 ? (
            <p className="no-jobs">No jobs posted yet. Click "Post New Job" to start.</p>
          ) : (
            jobs.map(job => (
              <div key={job._id} className="job-card-recruiter">
                <div className="job-header">
                  <div>
                    <h3>{job.jobTitle}</h3>
                    <p className="company">{job.companyName} • {job.location}</p>
                  </div>
                  <button 
                    className="view-applicants-btn"
                    onClick={() => handleViewApplicants(job._id)}
                  >
                    {selectedJob === job._id ? 'Hide' : 'View'} Applicants ({applications[job._id]?.length || 0})
                  </button>
                </div>
                <div className="job-details">
                  <span className="salary">💰 {job.salary}</span>
                  <span className="skills">🎯 Skills: {job.requiredSkills?.join(', ')}</span>
                </div>

                {/* Applicants List */}
                {selectedJob === job._id && applications[job._id] && (
                  <div className="applicants-list">
                    <h4>Applicants ({applications[job._id].length})</h4>
                    {applications[job._id].length === 0 ? (
                      <p>No applicants yet.</p>
                    ) : (
                      <table className="applicants-table">
                        <thead>
                          <tr>
                            <th>Student</th>
                            <th>ATS Score</th>
                            <th>Status</th>
                            <th>Resume</th>
                            <th>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {applications[job._id].map(app => (
                            <tr key={app._id}>
                              <td>{app.studentId?.name || app.studentId}</td>
                              <td>
                                <div className="ats-score">
                                  <span className="score-value">
                                    {app.resumeAnalyzed ? `${app.atsScore}%` : 'Pending'}
                                  </span>
                                  {app.resumeAnalyzed && (
                                    <div className="score-bar">
                                      <div className="score-fill" style={{width: `${app.atsScore}%`}}></div>
                                    </div>
                                  )}
                                </div>
                              </td>
                              <td>
                                <span className="status-badge" style={{background: getStatusColor(app.status)}}>
                                  {app.status}
                                </span>
                              </td>
                              <td>
                                <button 
                                  className="view-resume-btn" 
                                  onClick={() => window.open(`/resume/${app.studentId}`, '_blank')}
                                >
                                  📄 View Resume
                                </button>
                              </td>
                              <td>
                                <div className="action-buttons">
                                  {!app.resumeAnalyzed && (
                                    <button 
                                      onClick={() => handleAnalyzeResume(app._id)}
                                      className="action-btn analyze"
                                      disabled={analyzing}
                                    >
                                      🔍 Analyze Resume
                                    </button>
                                  )}
                                  {app.status !== 'Shortlisted' && (
                                    <button 
                                      onClick={() => updateStatus(app._id, 'Shortlisted')}
                                      className="action-btn shortlist"
                                      disabled={!app.resumeAnalyzed}
                                    >
                                      ✅ Shortlist
                                    </button>
                                  )}
                                  {app.status !== 'Selected' && (
                                    <button 
                                      onClick={() => updateStatus(app._id, 'Selected')}
                                      className="action-btn select"
                                      disabled={!app.resumeAnalyzed}
                                    >
                                      🎉 Select
                                    </button>
                                  )}
                                  {app.status !== 'Rejected' && (
                                    <button 
                                      onClick={() => updateStatus(app._id, 'Rejected')}
                                      className="action-btn reject"
                                      disabled={!app.resumeAnalyzed}
                                    >
                                      ❌ Reject
                                    </button>
                                  )}
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    )}
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default RecruiterDashboard;