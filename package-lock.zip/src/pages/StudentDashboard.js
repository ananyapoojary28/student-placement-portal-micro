import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getStudentProfile, updateStudentProfile, getJobs, getMyApplications, getProfile } from '../services/api';
import './Dashboard.css';

const StudentDashboard = () => {
  const [profile, setProfile] = useState(null);
  const [userData, setUserData] = useState(null);
  const [jobs, setJobs] = useState([]);
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    college: '',
    branch: '',
    cgpa: '',
    skills: [],
    github: '',
    linkedin: '',
    profileImage: ''
  });
  const [newSkill, setNewSkill] = useState('');
  const [newSkillLevel, setNewSkillLevel] = useState('Intermediate');
  const [selectedImage, setSelectedImage] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [profileRes, jobsRes, appsRes, userRes] = await Promise.all([
        getStudentProfile(),
        getJobs(),
        getMyApplications(),
        getProfile()
      ]);
      setProfile(profileRes.data);
      setUserData(userRes.data);
      setJobs(jobsRes.data);
      setApplications(appsRes.data);
      setFormData({
        name: userRes.data.name || '',
        email: userRes.data.email || '',
        college: profileRes.data.college || '',
        branch: profileRes.data.branch || '',
        cgpa: profileRes.data.cgpa || '',
        skills: profileRes.data.skills || [],
        github: profileRes.data.github || '',
        linkedin: profileRes.data.linkedin || '',
        profileImage: profileRes.data.profileImage || ''
      });
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  // Handle image upload
  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result);
        setFormData({ ...formData, profileImage: reader.result });
      };
      reader.readAsDataURL(file);
    }
  };

  // Calculate profile completion percentage
  const calculateCompletion = () => {
    if (!profile) return 0;
    let completed = 0;
    let total = 6;
    if (profile.college) completed++;
    if (profile.branch) completed++;
    if (profile.cgpa && profile.cgpa > 0) completed++;
    if (profile.skills && profile.skills.length > 0) completed++;
    if (profile.github) completed++;
    if (profile.linkedin) completed++;
    return Math.round((completed / total) * 100);
  };

  // Calculate placement readiness score
  const calculateReadiness = () => {
    if (!profile) return 0;
    let score = 0;
    if (profile.cgpa && profile.cgpa >= 8) score += 30;
    else if (profile.cgpa && profile.cgpa >= 7) score += 20;
    else if (profile.cgpa && profile.cgpa >= 6) score += 10;
    
    if (profile.skills && profile.skills.length >= 5) score += 40;
    else if (profile.skills && profile.skills.length >= 3) score += 25;
    else if (profile.skills && profile.skills.length >= 1) score += 15;
    
    if (profile.projects && profile.projects.length >= 2) score += 30;
    else if (profile.projects && profile.projects.length >= 1) score += 15;
    
    return Math.min(100, score);
  };

  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    try {
      // Update student profile only (college, branch, cgpa, skills, etc.)
      const studentData = {
        college: formData.college,
        branch: formData.branch,
        cgpa: formData.cgpa,
        skills: formData.skills,
        github: formData.github,
        linkedin: formData.linkedin,
        profileImage: formData.profileImage
      };
      
      await updateStudentProfile(studentData);
      
      // Update name and email in localStorage only
      const user = JSON.parse(localStorage.getItem('user'));
      user.name = formData.name;
      user.email = formData.email;
      localStorage.setItem('user', JSON.stringify(user));
      
      // Update displayed userData
      setUserData({ ...userData, name: formData.name, email: formData.email });
      
      setEditing(false);
      fetchData();
      alert('Profile updated successfully!');
    } catch (error) {
      console.error('Error updating profile:', error);
      alert('Error updating profile. Please try again.');
    }
  };

  const addSkill = () => {
    if (newSkill.trim()) {
      setFormData({
        ...formData,
        skills: [...formData.skills, { name: newSkill, level: newSkillLevel }]
      });
      setNewSkill('');
      setNewSkillLevel('Intermediate');
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login');
  };

  const completionPercentage = calculateCompletion();
  const readinessScore = calculateReadiness();

  if (loading) return <div className="loading">Loading...</div>;

  return (
    <div className="dashboard">
      <nav className="dashboard-nav">
        <h1>🎓 Student Dashboard</h1>
        <div className="nav-buttons">
          <button onClick={() => navigate('/resume-builder')} className="resume-btn">
            📄 Build Resume
          </button>
          <button onClick={logout} className="logout-btn">Logout</button>
        </div>
      </nav>

      <div className="dashboard-content">
        {/* Enhanced Profile Section */}
        <div className="profile-section enhanced">
          <div className="profile-header">
            <div className="profile-avatar" onClick={() => document.getElementById('imageUpload').click()}>
              {formData.profileImage || selectedImage ? (
                <img 
                  src={selectedImage || formData.profileImage} 
                  alt="Profile" 
                  className="avatar-image"
                />
              ) : userData?.name ? (
                <div className="avatar-initials">
                  {userData.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)}
                </div>
              ) : (
                <div className="avatar-icon">👤</div>
              )}
              <div className="avatar-edit-icon">📷</div>
              <input
                type="file"
                id="imageUpload"
                accept="image/*"
                style={{ display: 'none' }}
                onChange={handleImageUpload}
              />
              {completionPercentage === 100 && (
                <div className="verified-badge">✓</div>
              )}
            </div>
            <div className="profile-info">
              <h2>{userData?.name || 'Student Name'}</h2>
              <p className="profile-email">{userData?.email || 'email@example.com'}</p>
              <span className="profile-role">🎓 Student</span>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="stats-cards">
            <div className="stat-card-mini">
              <div className="stat-icon">📊</div>
              <div className="stat-info">
                <span className="stat-value-mini">{completionPercentage}%</span>
                <span className="stat-label-mini">Profile Complete</span>
              </div>
            </div>
            <div className="stat-card-mini">
              <div className="stat-icon">🏆</div>
              <div className="stat-info">
                <span className="stat-value-mini">{readinessScore}%</span>
                <span className="stat-label-mini">Placement Ready</span>
              </div>
            </div>
            <div className="stat-card-mini">
              <div className="stat-icon">⚡</div>
              <div className="stat-info">
                <span className="stat-value-mini">{profile?.skills?.length || 0}</span>
                <span className="stat-label-mini">Skills</span>
              </div>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="completion-bar">
            <div className="progress-label">
              <span>Profile Completion</span>
              <span>{completionPercentage}%</span>
            </div>
            <div className="progress-bar">
              <div className="progress-fill" style={{ width: `${completionPercentage}%` }}></div>
            </div>
          </div>

          {/* Education Section */}
          <div className="profile-detail-section">
            <h3>📚 Education</h3>
            <div className="detail-grid">
              <div className="detail-item">
                <span className="detail-label">College</span>
                <span className="detail-value">{profile?.college || 'Not set'}</span>
              </div>
              <div className="detail-item">
                <span className="detail-label">Branch</span>
                <span className="detail-value">{profile?.branch || 'Not set'}</span>
              </div>
              <div className="detail-item">
                <span className="detail-label">CGPA</span>
                <span className="detail-value">{profile?.cgpa || 'Not set'}</span>
              </div>
            </div>
          </div>

          {/* Skills Section with Levels */}
          <div className="profile-detail-section">
            <h3>⚡ Skills & Proficiency</h3>
            {profile?.skills?.length > 0 ? (
              <div className="skills-list-enhanced">
                {profile.skills.map((skill, i) => (
                  <div key={i} className="skill-item-enhanced">
                    <span className="skill-name">{skill.name}</span>
                    <span className={`skill-level ${skill.level?.toLowerCase()}`}>
                      {skill.level || 'Beginner'}
                    </span>
                    <div className="skill-bar">
                      <div className={`skill-fill ${skill.level?.toLowerCase()}`} style={{
                        width: skill.level === 'Advanced' ? '90%' : skill.level === 'Intermediate' ? '60%' : '30%'
                      }}></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="no-data">No skills added yet. Click Edit Profile to add skills.</p>
            )}
          </div>

          {/* Recommended Skills */}
          {profile?.skills && profile.skills.length > 0 && (
            <div className="profile-detail-section">
              <h3>🎯 Recommended Skills</h3>
              <div className="recommended-skills">
                {!profile.skills.find(s => s.name === 'Express.js') && (
                  <span className="rec-skill">Express.js</span>
                )}
                {!profile.skills.find(s => s.name === 'TypeScript') && (
                  <span className="rec-skill">TypeScript</span>
                )}
                {!profile.skills.find(s => s.name === 'Docker') && (
                  <span className="rec-skill">Docker</span>
                )}
                {!profile.skills.find(s => s.name === 'AWS') && (
                  <span className="rec-skill">AWS</span>
                )}
              </div>
            </div>
          )}

          {/* Social Links */}
          <div className="profile-detail-section">
            <h3>🔗 Social Links</h3>
            <div className="social-links">
              <div className="social-item">
                <span className="social-icon">🐙</span>
                <span className="social-label">GitHub:</span>
                <span className="social-value">{profile?.github || 'Not added'}</span>
              </div>
              <div className="social-item">
                <span className="social-icon">🔗</span>
                <span className="social-label">LinkedIn:</span>
                <span className="social-value">{profile?.linkedin || 'Not added'}</span>
              </div>
            </div>
          </div>

          {/* Last Updated */}
          <div className="profile-footer">
            <span className="last-updated">
              📅 Last updated: {profile?.updatedAt ? new Date(profile.updatedAt).toLocaleDateString() : 'Never'}
            </span>
            <button onClick={() => setEditing(true)} className="edit-profile-btn">
              ✏️ Edit Profile
            </button>
          </div>
        </div>

        {/* Edit Profile Modal */}
        {editing && (
          <div className="modal-overlay" onClick={() => setEditing(false)}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()}>
              <h2>Edit Profile</h2>
              <form onSubmit={handleUpdateProfile}>
                <div className="profile-image-upload">
                  <label>Profile Picture</label>
                  <div className="image-preview" onClick={() => document.getElementById('editImageUpload').click()}>
                    {selectedImage || formData.profileImage ? (
                      <img src={selectedImage || formData.profileImage} alt="Preview" />
                    ) : (
                      <div className="image-placeholder">Click to upload</div>
                    )}
                  </div>
                  <input
                    type="file"
                    id="editImageUpload"
                    accept="image/*"
                    style={{ display: 'none' }}
                    onChange={handleImageUpload}
                  />
                </div>
                
                {/* Name and Email Fields */}
                <input
                  type="text"
                  placeholder="Full Name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  required
                />
                <input
                  type="email"
                  placeholder="Email Address"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  required
                />
                
                <input
                  type="text"
                  placeholder="College"
                  value={formData.college}
                  onChange={(e) => setFormData({...formData, college: e.target.value})}
                />
                <input
                  type="text"
                  placeholder="Branch"
                  value={formData.branch}
                  onChange={(e) => setFormData({...formData, branch: e.target.value})}
                />
                <input
                  type="number"
                  placeholder="CGPA"
                  step="0.1"
                  value={formData.cgpa}
                  onChange={(e) => setFormData({...formData, cgpa: e.target.value})}
                />
                
                {/* Skills Section */}
                <div className="form-section">
                  <h3>⚡ Skills & Proficiency</h3>
                  <div className="skills-input">
                    <input
                      type="text"
                      placeholder="Skill Name (e.g., React, Node.js)"
                      value={newSkill}
                      onChange={(e) => setNewSkill(e.target.value)}
                    />
                    <select value={newSkillLevel} onChange={(e) => setNewSkillLevel(e.target.value)}>
                      <option value="Beginner">Beginner</option>
                      <option value="Intermediate">Intermediate</option>
                      <option value="Advanced">Advanced</option>
                    </select>
                    <button type="button" onClick={addSkill}>+ Add</button>
                  </div>
                  <div className="skills-list">
                    {formData.skills.map((skill, i) => (
                      <span key={i} className="skill-tag">
                        {skill.name} ({skill.level})
                        <button 
                          type="button" 
                          onClick={() => {
                            const newSkills = formData.skills.filter((_, idx) => idx !== i);
                            setFormData({...formData, skills: newSkills});
                          }}
                          className="remove-skill"
                        >×</button>
                      </span>
                    ))}
                  </div>
                </div>
                
                <input
                  type="text"
                  placeholder="GitHub Username"
                  value={formData.github}
                  onChange={(e) => setFormData({...formData, github: e.target.value})}
                />
                <input
                  type="text"
                  placeholder="LinkedIn Username"
                  value={formData.linkedin}
                  onChange={(e) => setFormData({...formData, linkedin: e.target.value})}
                />
                <div className="form-buttons">
                  <button type="submit" className="save-btn">Save Changes</button>
                  <button type="button" onClick={() => setEditing(false)} className="cancel-btn">Cancel</button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Jobs Section */}
        <div className="jobs-section">
          <h2>💼 Available Jobs</h2>
          <div className="jobs-list">
            {jobs.length === 0 ? (
              <p className="no-jobs">No jobs available at the moment. Check back later!</p>
            ) : (
              jobs.map(job => (
                <div key={job._id} className="job-card">
                  <h3>{job.jobTitle}</h3>
                  <p className="company-name">🏢 {job.companyName} • 📍 {job.location}</p>
                  <p className="salary">💰 {job.salary}</p>
                  <p className="skills-req">🎯 Required: {job.requiredSkills?.join(', ')}</p>
                  <p className="deadline">⏰ Deadline: {new Date(job.deadline).toLocaleDateString()}</p>
                  <button onClick={() => navigate(`/apply/${job._id}`)} className="apply-btn">
                    Apply Now →
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Applications Section - WITHOUT ATS SCORE */}
        <div className="applications-section">
          <h2>📋 My Applications</h2>
          <div className="applications-list">
            {applications.length === 0 ? (
              <p className="no-applications">You haven't applied to any jobs yet.</p>
            ) : (
              applications.map(app => (
                <div key={app._id} className="application-card">
                  <div className="application-header">
                    <strong>Job ID:</strong> {app.jobId}
                    <span className={`status-badge status-${app.status.toLowerCase()}`}>
                      {app.status}
                    </span>
                  </div>
                  <div className="application-details">
                    <p><strong>Applied:</strong> {new Date(app.appliedDate).toLocaleDateString()}</p>
                    {app.notes && <p><strong>Notes:</strong> {app.notes}</p>}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;