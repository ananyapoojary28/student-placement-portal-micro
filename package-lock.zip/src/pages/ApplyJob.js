import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getJobById, applyForJob, getStudentProfile } from '../services/api';
import './ApplyJob.css';

const ApplyJob = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [job, setJob] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [applying, setApplying] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetchData();
  }, [id]);

  const fetchData = async () => {
    try {
      const [jobRes, profileRes] = await Promise.all([
        getJobById(id),
        getStudentProfile()
      ]);
      setJob(jobRes.data);
      setProfile(profileRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateMatchScore = () => {
    if (!profile || !job) return 0;
    
    const userSkills = profile.skills?.map(s => s.name.toLowerCase()) || [];
    const jobSkills = job.requiredSkills?.map(s => s.toLowerCase()) || [];
    
    const matchedSkills = userSkills.filter(skill => jobSkills.includes(skill));
    const matchScore = jobSkills.length > 0 
      ? (matchedSkills.length / jobSkills.length) * 100 
      : 0;
    
    return Math.round(matchScore);
  };

  const handleApply = async () => {
    setApplying(true);
    try {
      await applyForJob({ jobId: id });
      setMessage('Application submitted successfully!');
      setTimeout(() => {
        navigate('/student/dashboard');
      }, 2000);
    } catch (error) {
      setMessage(error.response?.data?.message || 'Failed to apply');
    } finally {
      setApplying(false);
    }
  };

  if (loading) return <div className="loading">Loading...</div>;
  if (!job) return <div className="loading">Job not found</div>;

  const matchScore = calculateMatchScore();

  return (
    <div className="apply-container">
      <button onClick={() => navigate(-1)} className="back-btn">← Back</button>
      
      <div className="job-details">
        <h1>{job.jobTitle}</h1>
        <p className="company">{job.companyName}</p>
        <p className="location">📍 {job.location}</p>
        <p className="salary">💰 {job.salary}</p>
        
        <div className="section">
          <h3>Required Skills</h3>
          <div className="skills-list">
            {job.requiredSkills?.map((skill, i) => (
              <span key={i} className="skill-tag">{skill}</span>
            ))}
          </div>
        </div>
        
        <div className="section">
          <h3>Job Description</h3>
          <p>{job.description}</p>
        </div>
        
        <div className="section">
          <h3>Deadline</h3>
          <p>{new Date(job.deadline).toLocaleDateString()}</p>
        </div>
        
        <div className="match-score">
          <h3>Your Match Score</h3>
          <div className="score-bar">
            <div className="score-fill" style={{ width: `${matchScore}%` }}></div>
          </div>
          <p className="score-percentage">{matchScore}%</p>
        </div>
        
        {message && <div className="message">{message}</div>}
        
        <button 
          onClick={handleApply} 
          className="apply-btn"
          disabled={applying}
        >
          {applying ? 'Applying...' : 'Apply Now'}
        </button>
      </div>
    </div>
  );
};

export default ApplyJob;