import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getStudentProfile, getProfile } from '../services/api';
import './ResumeView.css';

const ResumeView = () => {
  const { studentId } = useParams();
  const [resume, setResume] = useState(null);
  const [student, setStudent] = useState(null);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchResume();
  }, [studentId]);

  const fetchResume = async () => {
    try {
      // Fetch student profile
      const studentRes = await getStudentProfile(studentId);
      setStudent(studentRes.data);
      
      // Fetch user details (name, email)
      const userRes = await getProfile(studentId);
      setUser(userRes.data);
      
      setResume({
        personalInfo: {
          name: userRes.data?.name || 'Student',
          email: userRes.data?.email || '',
          phone: studentRes.data?.phone || ''
        },
        education: [{
          degree: studentRes.data?.branch ? `B.Tech in ${studentRes.data.branch}` : '',
          institution: studentRes.data?.college || '',
          year: '',
          percentage: studentRes.data?.cgpa ? `${studentRes.data.cgpa} CGPA` : ''
        }],
        skills: studentRes.data?.skills?.map(s => s.name) || [],
        projects: studentRes.data?.projects || []
      });
    } catch (error) {
      console.error('Error fetching resume:', error);
    } finally {
      setLoading(false);
    }
  };

  // Check if user is recruiter to go back to recruiter dashboard
  const handleBack = () => {
    const userRole = JSON.parse(localStorage.getItem('user'))?.role;
    if (userRole === 'recruiter') {
      navigate('/recruiter/dashboard');
    } else {
      navigate(-1);
    }
  };

  if (loading) return <div className="loading">Loading resume...</div>;

  return (
    <div className="resume-view-container">
      <button onClick={handleBack} className="back-btn">← Back to Dashboard</button>
      <div className="resume-view-card">
        <h1>{resume?.personalInfo?.name || 'Student Resume'}</h1>
        <p>Email: {resume?.personalInfo?.email || 'Not provided'}</p>
        <p>Phone: {resume?.personalInfo?.phone || 'Not provided'}</p>
        
        <h3>📚 Education</h3>
        {resume?.education?.map((edu, i) => (
          <div key={i} className="education-item">
            <strong>{edu.degree}</strong> - {edu.institution}
            <div>{edu.year} | {edu.percentage}</div>
          </div>
        ))}
        
        <h3>⚡ Skills</h3>
        <div className="skills-list">
          {resume?.skills?.length > 0 ? (
            resume.skills.map((skill, i) => (
              <span key={i} className="skill-badge">{skill}</span>
            ))
          ) : (
            <p>No skills added</p>
          )}
        </div>
        
        <h3>🚀 Projects</h3>
        {resume?.projects?.length > 0 ? (
          resume.projects.map((project, i) => (
            <div key={i} className="project-item">
              <strong>{project.title}</strong>
              <p>{project.description}</p>
              {project.technologies && (
                <small>Technologies: {project.technologies}</small>
              )}
            </div>
          ))
        ) : (
          <p>No projects added</p>
        )}
        
        <button onClick={() => window.print()} className="print-btn">
          🖨️ Print Resume
        </button>
      </div>
    </div>
  );
};

export default ResumeView;