import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getStudentProfile, getProfile } from '../services/api';
import html2pdf from 'html2pdf.js';
import './ResumeBuilder.css';

const ResumeBuilder = () => {
  const [profile, setProfile] = useState(null);
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [resumeData, setResumeData] = useState({
    personalInfo: {
      name: '',
      email: '',
      phone: '',
      address: '',
      linkedin: '',
      github: ''
    },
    education: [{
      degree: '',
      institution: '',
      year: '',
      percentage: ''
    }],
    skills: [],
    projects: [{
      title: '',
      description: '',
      technologies: '',
      link: ''
    }],
    experience: [{
      title: '',
      company: '',
      duration: '',
      description: ''
    }],
    certifications: [{
      name: '',
      issuer: '',
      year: ''
    }],
    template: 'professional'
  });
  
  const navigate = useNavigate();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const userRes = await getProfile();
      const profileRes = await getStudentProfile();
      setUserData(userRes.data);
      setProfile(profileRes.data);
      
      // Auto-fill from existing profile
      setResumeData({
        ...resumeData,
        personalInfo: {
          name: userRes.data.name || '',
          email: userRes.data.email || '',
          phone: '',
          address: '',
          linkedin: profileRes.data.linkedin || '',
          github: profileRes.data.github || ''
        },
        skills: profileRes.data.skills?.map(s => s.name) || [],
        education: [{
          degree: profileRes.data.branch ? `B.Tech in ${profileRes.data.branch}` : '',
          institution: profileRes.data.college || '',
          year: '',
          percentage: profileRes.data.cgpa ? `${profileRes.data.cgpa} CGPA` : ''
        }]
      });
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  // Add/Remove functions
  const addEducation = () => {
    setResumeData({
      ...resumeData,
      education: [...resumeData.education, { degree: '', institution: '', year: '', percentage: '' }]
    });
  };

  const removeEducation = (index) => {
    const newEducation = resumeData.education.filter((_, i) => i !== index);
    setResumeData({ ...resumeData, education: newEducation });
  };

  const addProject = () => {
    setResumeData({
      ...resumeData,
      projects: [...resumeData.projects, { title: '', description: '', technologies: '', link: '' }]
    });
  };

  const removeProject = (index) => {
    const newProjects = resumeData.projects.filter((_, i) => i !== index);
    setResumeData({ ...resumeData, projects: newProjects });
  };

  const addExperience = () => {
    setResumeData({
      ...resumeData,
      experience: [...resumeData.experience, { title: '', company: '', duration: '', description: '' }]
    });
  };

  const removeExperience = (index) => {
    const newExperience = resumeData.experience.filter((_, i) => i !== index);
    setResumeData({ ...resumeData, experience: newExperience });
  };

  const addCertification = () => {
    setResumeData({
      ...resumeData,
      certifications: [...resumeData.certifications, { name: '', issuer: '', year: '' }]
    });
  };

  const removeCertification = (index) => {
    const newCertifications = resumeData.certifications.filter((_, i) => i !== index);
    setResumeData({ ...resumeData, certifications: newCertifications });
  };

  // Generate PDF with AI formatting
  const generatePDF = () => {
    setGenerating(true);
    
    const element = document.getElementById('resume-preview');
    const opt = {
      margin: 0.5,
      filename: `${resumeData.personalInfo.name || 'resume'}_resume.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, letterRendering: true },
      jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
    };
    
    html2pdf().set(opt).from(element).save();
    setGenerating(false);
    alert('Resume generated and downloaded successfully!');
  };

  const updatePersonalInfo = (field, value) => {
    setResumeData({
      ...resumeData,
      personalInfo: { ...resumeData.personalInfo, [field]: value }
    });
  };

  const updateEducation = (index, field, value) => {
    const newEducation = [...resumeData.education];
    newEducation[index][field] = value;
    setResumeData({ ...resumeData, education: newEducation });
  };

  const updateProject = (index, field, value) => {
    const newProjects = [...resumeData.projects];
    newProjects[index][field] = value;
    setResumeData({ ...resumeData, projects: newProjects });
  };

  const updateExperience = (index, field, value) => {
    const newExperience = [...resumeData.experience];
    newExperience[index][field] = value;
    setResumeData({ ...resumeData, experience: newExperience });
  };

  const updateCertification = (index, field, value) => {
    const newCertifications = [...resumeData.certifications];
    newCertifications[index][field] = value;
    setResumeData({ ...resumeData, certifications: newCertifications });
  };

  if (loading) return <div className="loading">Loading...</div>;

  return (
    <div className="resume-builder">
      <nav className="resume-nav">
        <h1>📄 AI Resume Builder</h1>
        <button onClick={() => navigate('/student/dashboard')} className="back-btn">← Back to Dashboard</button>
      </nav>

      <div className="resume-container">
        {/* Form Section */}
        <div className="resume-form">
          <h2>Enter Your Details</h2>
          
          {/* Personal Info */}
          <div className="form-section">
            <h3>Personal Information</h3>
            <div className="form-grid">
              <input type="text" placeholder="Full Name" value={resumeData.personalInfo.name}
                onChange={(e) => updatePersonalInfo('name', e.target.value)} />
              <input type="email" placeholder="Email" value={resumeData.personalInfo.email}
                onChange={(e) => updatePersonalInfo('email', e.target.value)} />
              <input type="tel" placeholder="Phone" value={resumeData.personalInfo.phone}
                onChange={(e) => updatePersonalInfo('phone', e.target.value)} />
              <input type="text" placeholder="Address" value={resumeData.personalInfo.address}
                onChange={(e) => updatePersonalInfo('address', e.target.value)} />
              <input type="text" placeholder="LinkedIn URL" value={resumeData.personalInfo.linkedin}
                onChange={(e) => updatePersonalInfo('linkedin', e.target.value)} />
              <input type="text" placeholder="GitHub URL" value={resumeData.personalInfo.github}
                onChange={(e) => updatePersonalInfo('github', e.target.value)} />
            </div>
          </div>

          {/* Education */}
          <div className="form-section">
            <h3>Education</h3>
            {resumeData.education.map((edu, index) => (
              <div key={index} className="form-card">
                <div className="form-row">
                  <input type="text" placeholder="Degree" value={edu.degree}
                    onChange={(e) => updateEducation(index, 'degree', e.target.value)} />
                  <input type="text" placeholder="Institution" value={edu.institution}
                    onChange={(e) => updateEducation(index, 'institution', e.target.value)} />
                </div>
                <div className="form-row">
                  <input type="text" placeholder="Year" value={edu.year}
                    onChange={(e) => updateEducation(index, 'year', e.target.value)} />
                  <input type="text" placeholder="Percentage/CGPA" value={edu.percentage}
                    onChange={(e) => updateEducation(index, 'percentage', e.target.value)} />
                </div>
                {resumeData.education.length > 1 && (
                  <button type="button" onClick={() => removeEducation(index)} className="remove-btn">Remove</button>
                )}
              </div>
            ))}
            <button type="button" onClick={addEducation} className="add-btn">+ Add Education</button>
          </div>

          {/* Skills */}
          <div className="form-section">
            <h3>Skills</h3>
            <div className="skills-input">
              <input type="text" placeholder="Add skill (e.g., React, Node.js)"
                onKeyPress={(e) => {
                  if (e.key === 'Enter' && e.target.value) {
                    setResumeData({
                      ...resumeData,
                      skills: [...resumeData.skills, e.target.value]
                    });
                    e.target.value = '';
                  }
                }} />
            </div>
            <div className="skills-tags">
              {resumeData.skills.map((skill, index) => (
                <span key={index} className="skill-tag">
                  {skill}
                  <button onClick={() => {
                    const newSkills = resumeData.skills.filter((_, i) => i !== index);
                    setResumeData({ ...resumeData, skills: newSkills });
                  }}>×</button>
                </span>
              ))}
            </div>
          </div>

          {/* Projects */}
          <div className="form-section">
            <h3>Projects</h3>
            {resumeData.projects.map((project, index) => (
              <div key={index} className="form-card">
                <input type="text" placeholder="Project Title" value={project.title}
                  onChange={(e) => updateProject(index, 'title', e.target.value)} />
                <textarea placeholder="Project Description" rows="2" value={project.description}
                  onChange={(e) => updateProject(index, 'description', e.target.value)} />
                <input type="text" placeholder="Technologies Used" value={project.technologies}
                  onChange={(e) => updateProject(index, 'technologies', e.target.value)} />
                <input type="text" placeholder="Project Link (optional)" value={project.link}
                  onChange={(e) => updateProject(index, 'link', e.target.value)} />
                {resumeData.projects.length > 1 && (
                  <button type="button" onClick={() => removeProject(index)} className="remove-btn">Remove</button>
                )}
              </div>
            ))}
            <button type="button" onClick={addProject} className="add-btn">+ Add Project</button>
          </div>

          {/* Experience */}
          <div className="form-section">
            <h3>Experience</h3>
            {resumeData.experience.map((exp, index) => (
              <div key={index} className="form-card">
                <div className="form-row">
                  <input type="text" placeholder="Job Title" value={exp.title}
                    onChange={(e) => updateExperience(index, 'title', e.target.value)} />
                  <input type="text" placeholder="Company" value={exp.company}
                    onChange={(e) => updateExperience(index, 'company', e.target.value)} />
                </div>
                <input type="text" placeholder="Duration (e.g., Jan 2023 - Present)" value={exp.duration}
                  onChange={(e) => updateExperience(index, 'duration', e.target.value)} />
                <textarea placeholder="Job Description" rows="2" value={exp.description}
                  onChange={(e) => updateExperience(index, 'description', e.target.value)} />
                {resumeData.experience.length > 1 && (
                  <button type="button" onClick={() => removeExperience(index)} className="remove-btn">Remove</button>
                )}
              </div>
            ))}
            <button type="button" onClick={addExperience} className="add-btn">+ Add Experience</button>
          </div>

          {/* Certifications */}
          <div className="form-section">
            <h3>Certifications</h3>
            {resumeData.certifications.map((cert, index) => (
              <div key={index} className="form-card">
                <div className="form-row">
                  <input type="text" placeholder="Certification Name" value={cert.name}
                    onChange={(e) => updateCertification(index, 'name', e.target.value)} />
                  <input type="text" placeholder="Issuer" value={cert.issuer}
                    onChange={(e) => updateCertification(index, 'issuer', e.target.value)} />
                </div>
                <input type="text" placeholder="Year" value={cert.year}
                  onChange={(e) => updateCertification(index, 'year', e.target.value)} />
                {resumeData.certifications.length > 1 && (
                  <button type="button" onClick={() => removeCertification(index)} className="remove-btn">Remove</button>
                )}
              </div>
            ))}
            <button type="button" onClick={addCertification} className="add-btn">+ Add Certification</button>
          </div>

          <button className="generate-btn" onClick={generatePDF} disabled={generating}>
            {generating ? 'Generating...' : '🎯 Generate Professional Resume'}
          </button>
        </div>

        {/* Preview Section */}
        <div className="resume-preview">
          <h2>Live Preview</h2>
          <div id="resume-preview" className="preview-content">
            {/* Professional Resume Template */}
            <div className="resume-template professional">
              <div className="resume-header">
                <h1>{resumeData.personalInfo.name || 'Your Name'}</h1>
                <div className="contact-info">
                  {resumeData.personalInfo.email && <span>📧 {resumeData.personalInfo.email}</span>}
                  {resumeData.personalInfo.phone && <span>📞 {resumeData.personalInfo.phone}</span>}
                  {resumeData.personalInfo.address && <span>📍 {resumeData.personalInfo.address}</span>}
                </div>
                <div className="social-links">
                  {resumeData.personalInfo.linkedin && <span>🔗 {resumeData.personalInfo.linkedin}</span>}
                  {resumeData.personalInfo.github && <span>💻 {resumeData.personalInfo.github}</span>}
                </div>
              </div>

              <div className="resume-section">
                <h3>Education</h3>
                {resumeData.education.map((edu, i) => (
                  <div key={i} className="education-item">
                    <strong>{edu.degree}</strong> - {edu.institution}
                    <div>{edu.year} | {edu.percentage}</div>
                  </div>
                ))}
              </div>

              <div className="resume-section">
                <h3>Skills</h3>
                <div className="skills-list">
                  {resumeData.skills.map((skill, i) => (
                    <span key={i} className="skill-badge">{skill}</span>
                  ))}
                </div>
              </div>

              <div className="resume-section">
                <h3>Projects</h3>
                {resumeData.projects.map((project, i) => (
                  <div key={i} className="project-item">
                    <strong>{project.title}</strong>
                    <div>{project.description}</div>
                    <div className="tech-stack">Technologies: {project.technologies}</div>
                    {project.link && <a href={project.link} target="_blank">View Project</a>}
                  </div>
                ))}
              </div>

              <div className="resume-section">
                <h3>Experience</h3>
                {resumeData.experience.map((exp, i) => (
                  <div key={i} className="experience-item">
                    <strong>{exp.title}</strong> at {exp.company}
                    <div>{exp.duration}</div>
                    <div>{exp.description}</div>
                  </div>
                ))}
              </div>

              <div className="resume-section">
                <h3>Certifications</h3>
                {resumeData.certifications.map((cert, i) => (
                  <div key={i} className="cert-item">
                    <strong>{cert.name}</strong> - {cert.issuer} ({cert.year})
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResumeBuilder;