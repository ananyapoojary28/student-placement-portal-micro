import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Landing from './pages/Landing';
import Login from './pages/Login';
import Register from './pages/Register';
import StudentDashboard from './pages/StudentDashboard';
import RecruiterDashboard from './pages/RecruiterDashboard';
import ApplyJob from './pages/ApplyJob';
import ResumeBuilder from './pages/ResumeBuilder';
import './App.css';
import ResumeView from './pages/ResumeView';

function App() {
  const token = localStorage.getItem('token');
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  return (
    <Router>
      <div className="App">
        <Routes>
          {/* Landing Page - FIRST */}
          <Route path="/" element={<Landing />} />
          
          {/* Auth Routes */}
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          
          {/* Student Routes */}
          <Route 
            path="/student/dashboard" 
            element={token && user.role === 'student' ? <StudentDashboard /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/apply/:id" 
            element={token && user.role === 'student' ? <ApplyJob /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/resume-builder" 
            element={token && user.role === 'student' ? <ResumeBuilder /> : <Navigate to="/login" />} 
          />
          
          {/* Recruiter Routes */}
          <Route 
            path="/recruiter/dashboard" 
            element={token && user.role === 'recruiter' ? <RecruiterDashboard /> : <Navigate to="/login" />} 
          />
          <Route path="/resume/:studentId" element={<ResumeView />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;