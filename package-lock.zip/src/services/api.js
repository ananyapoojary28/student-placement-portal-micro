import axios from 'axios';

const API_URL = 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add token to requests
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// ===== AUTH APIS =====
export const register = (userData) => api.post('/auth/register', userData);
export const login = (userData) => api.post('/auth/login', userData);
export const getProfile = () => api.get('/auth/profile');
export const updateAuthProfile = (data) => api.put('/auth/profile', data);

// ===== STUDENT APIS =====
export const getStudentProfile = () => api.get('/student/profile');
export const updateStudentProfile = (data) => api.post('/student/profile', data);
export const addSkill = (data) => api.post('/student/skills', data);

// ===== JOB APIS =====
export const getJobs = () => api.get('/jobs');
export const getJobById = (id) => api.get(`/jobs/${id}`);
export const createJob = (data) => api.post('/jobs', data);

// ===== APPLICATION APIS =====
export const applyForJob = (data) => api.post('/applications', data);
export const getMyApplications = () => api.get('/applications/my-applications');
export const getApplicationsByJob = (jobId) => api.get(`/applications/job/${jobId}`);
export const updateApplicationStatus = (id, data) => api.put(`/applications/${id}/status`, data);
export const analyzeApplication = (id) => api.post(`/applications/${id}/analyze`);  // ← ADDED

// ===== RESUME APIS =====
export const getResume = () => api.get('/resume');
export const createResume = (data) => api.post('/resume', data);
export const generatePDF = () => api.post('/resume/generate-pdf');

export default api;